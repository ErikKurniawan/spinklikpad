<?php

require './config/cookie.php';
require './config/directory.php';
require './config/database.php';
require './config/encyption.php';
require './config/timezone.php';

