
<div class="container-fluid section content" style="height: 550px;">







    <div class="row">
        <div class="col-12" style="font-size:16px; color:#95999A;">
            <div style="display: inline-block;padding:0px 20px 0px 0px"> INFO KLIKPAD </div><div style="display: inline-block; padding-left:20px;border-left: 1px solid #e2e7e9;"> Tentang Kami</div>
        </div>
    </div>
    <div class="row">
        <!--
        <div class="col-6" style="font-size:12px; color:#95999A; margin-top:40px">


            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,
        </div>
        -->
    </div>
    <div class="row">
        <div class="col-6" style="font-size:12px; color:#95999A; margin-top:40px">
            
            <div style="color:#733f98;font-size:14px;font-weight: bold;text-align: justify">

                Halo sahabat yang luar biasa, pada kesempatan kali ini izinkan kami dari Klikpad.com untuk memperkenalkan diri. Mudah-mudahan dengan adanya perkenalan ini sahabat-sahabat sekalian akan lebih senang berbelanja di toko online ini.

                Sungguh terhormat bagi kami, jika Anda datang ke toko ini dan bisa memperoleh banyak hal yang bermanfaat.

                Klikpad.com adalah sebuah toko yang menyediakan Handphone, Tablet & Wearable Gadget, Kamera,Komputer & Laptop, Peralatan Elektronik, Fashion Pria, Fashion Wanita, Kesehatan & Kecantikan, Ibu & Anak, Olahraga & Aktivitas Luar Ruang, dan Alat-alat Sekolah.

                Seiring dengan semakin berkembangnya teknologi, maka kami mencoba berinovasi dalam berbisnis. Salah satu bentuk inovasinya adalah dengan menyediakan layanan toko online melalui media internet, dan toko online ini adalah salah satu bentuk pelayanan kami kepada Anda. Klikpad.com didirikan oleh Spin-international pada tahun 2017. 
            </div>
        </div>
    </div>

    <div class="row">
        <div class="offset-2 col-6" style=" margin-top:40px">
            <!--<div style="color:#733f98;font-size:18px;font-weight: bold;"">There are many variations of passages of Lorem Ipsum available,</div>-->
            <div style="color:#95999A;font-size:14px;font-weight: bold;text-align: justify">

                Keberadaan dari toko online ini diharapkan dapat mempermudah Anda untuk mendapatkan berbagai produk berkualitas tinggi namun dengan harga yang terjangkau.

                Dalam memberi layanan, kami selalu mencoba memberi persembahan terbaik kepada siapapun. Selain itu kami juga selalu menjunjung tinggi nilai-nilai etika yang baik, seperti kejujuran, ketepatan, dan profesionalitas dalam berbisnis. Mudah-mudahan dengannya toko online kami bisa memberi banyak manfaat bagi Anda.

                Sekian dulu perkenalan ini. Semoga perkenalan ini bisa memberi inspirasi dan manfaat bagi Anda.

                Semoga Anda sukses selalu.    

            </div>
        </div>
    </div>
</div>
