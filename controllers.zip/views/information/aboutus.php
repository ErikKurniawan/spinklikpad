
<div class="row">
<div class="container" style="border:0px solid red;">
              <h4><strong>TENTANG KAMI </strong></h4>
              <p> Halo sahabat yang luar biasa, pada kesempatan kali ini izinkan kami dari Klikpad.com untuk memperkenalkan diri. Mudah-mudahan dengan adanya perkenalan ini sahabat-sahabat sekalian akan lebih senang berbelanja di toko online ini. </p>
              <p>Sungguh terhormat bagi kami, jika Anda datang ke toko ini dan bisa memperoleh banyak hal yang bermanfaat. </p>
              <p>Klikpad.com adalah sebuah toko yang menyediakan Handphone, Tablet &amp; Wearable Gadget, Kamera,Komputer &amp; Laptop, Peralatan Elektronik, Fashion Pria, Fashion Wanita, Kesehatan &amp; Kecantikan, Ibu &amp; Anak, Olahraga &amp; Aktivitas Luar Ruang, dan Alat-alat Sekolah. </p>
              <p>Seiring dengan semakin berkembangnya teknologi, maka kami mencoba berinovasi dalam berbisnis. Salah satu bentuk inovasinya adalah dengan menyediakan layanan toko online melalui media internet, dan toko online ini adalah salah satu bentuk pelayanan kami kepada Anda. </p>
              <p>Klikpad.com didirikan oleh Spin-international pada tahun 2017. Keberadaan dari toko online ini diharapkan dapat mempermudah Anda untuk mendapatkan berbagai produk berkualitas tinggi namun dengan harga yang terjangkau. </p>
              <p>Dalam memberi layanan, kami selalu mencoba memberi persembahan terbaik kepada siapapun. Selain itu kami juga selalu menjunjung tinggi nilai-nilai etika yang baik, seperti kejujuran, ketepatan, dan profesionalitas dalam berbisnis. Mudah-mudahan dengannya toko online kami bisa memberi banyak manfaat bagi Anda. </p>
              <p>Sekian dulu perkenalan ini. Semoga perkenalan ini bisa memberi inspirasi dan manfaat bagi Anda. </p>
              <p>Semoga Anda sukses selalu. </p>
            </div>

</div>
