<?php
header("Content-type: application/x-javascript");

?>

$(function () {
    URLAPI = "<?=URLAPI?>";
});