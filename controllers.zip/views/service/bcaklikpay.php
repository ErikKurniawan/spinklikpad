    <div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong> BCA KLIKPAY</strong></p>
              <ol>
                <li>Setelah Anda menekan tombol "Konfirmasi Pembayaran", Anda akan diarahkan ke halaman pembayaran BCA KlikPay.<br>
                </li>
                <li>Setelah Login ke Akun BCA Klikpay Anda dengan memasukkan alamat email dan password, maka akan tampil informasi data transaksi seperti nama merchant, waktu transaksi, dan jumlah yang harus dibayar. Pilihlah jenis pembayaran KlikBCA atau BCA Card untuk transaksi tersebut.<br>
                </li>
                <li>Untuk otorisasi pembayaran dengan BCA KlikPay, tekan tombol "kirim OTP", dan Anda akan menerima kode OTP (One Time Password) yang dikirim melalui SMS ke handphone Anda. Masukkan kode OTP tersebut pada kolom yang tersedia.\</li>
                <li> Apabila kode OTP yang Anda masukkan benar, transaksi pembayaran akan langsung diproses dan saldo rekening Anda (untuk jenis pembayaran KlikBCA) atau limit BCA Card Anda (untuk jenis pembayaran BCA Card) akan berkurang sejumlah nilai transaksi.</li>
                <li>Status keberhasilan transaksi Anda akan tampil pada layar transaksi dan Anda akan menerima email notifikasi. </li>
              </ol>
            </div>
</div>