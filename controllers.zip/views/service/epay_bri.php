        <div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong> e-PAY BRI</strong></p>
              <ol>
                <li>Pembayaran menggunakan e-Pay BRI harus diselesaikan dari website Internet Banking BRI. Pastikan Anda telah memiliki User ID Internet Banking BRI dan sudah mendaftarkan mTOKEN sebelum melakukan melanjutkan pembayaran menggunakan e-Pay BRI.</li>
                <li> Untuk mendapatkan User ID Internet Banking BRI, silakan melakukan registrasi melalui ATM BRI terdekat.</li>
                <li> Untuk mendaftarkan mTOKEN, silakan melakukan registrasi finansial di cabang BRI terdekat.</li>
                <li>Pembayaran menggunakan e-Pay BRI akan diproses secara online, saldo rekening BRI Anda akan didebet secara otomatis sesuai jumlah pembelanjaan Anda. </li>
                <li> Transaksi Anda akan dibatalkan jika pembayaran tidak diselesaikan dalam 2 jam.</li>
              </ol>
            </div>
</div>