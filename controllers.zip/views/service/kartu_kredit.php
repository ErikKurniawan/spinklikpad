    <div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong> KARTU KREDIT</strong></p>
              <ol>
                <li>Ikuti langkah-langkah berikut untuk mengetahui cara membayar dengan kartu kredit: Klik <strong>“Kartu Kredit”</strong> pada kolom Pilih Metode Pembayaran di laman Pembayaran, isi Nomor Kartu Kredit, Berlaku Hingga, dan CVV. Klik <strong>“Bayar Sekarang“ </strong><br>
				<img src="<?php echo URL?>public/images/howtobuy/kartu_kredit1.png" width="719" height="392" alt=""/>
				  </li>
                <li>Selanjutnya Anda akan diarahkan ke laman Speedorder/Midtrans sesuai metode pembayaran pilihan Anda</li>
                <li>Isi dan lengkapi data Card Number, Card Brand, Card Expiry Date, dan Security Code (3 digit terakhir yang terdapat pada kolom tanda tangan kartu kredit Anda), dan Name on Card. Klik tombol <strong>“Process“</strong></li>
                <li>Jika Kartu Kredit Anda memerlukan Authentication (3D Secure), maka halaman OTP akan muncul dimana Anda harus meng-input kode dari Bank yang dikirimkan ke Handphone Anda (sesuai dengan nomor Handphone yang Anda daftarkan dengan pihak Bank). Jika kartu kredit Anda tidak memerlukan Authentication (3D Secure), maka proses pembayaran telah selesai dan Anda akan langsung diarahkan ke laman TERIMA KASIH<br>
                </li>
              </ol>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
          </div>
</div>