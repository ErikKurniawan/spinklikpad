<div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong>ATM / BANK TRANSFER MANDIRI</strong></p>
              <p>
              <ul>ATM MANDIRI</ul> 
              </p>
              <ol>
                <li>Pada menu utama, pilih Bayar/Beli.<br>
                </li>
                <li>Pilih Lainnya.<br>
                </li>
                <li>Pilih Multi Payment.<br>
                </li>
                <li>Masukkan 70012 (kode perusahaan Midtrans) lalu tekan Benar.<br>
                </li>
                <li>Masukkan Kode Pembayaran Anda lalu tekan Benar.<br>
                </li>
                <li>Pada halaman konfirmasi akan muncul detail pembayaran Anda. Jika informasi telah sesuai tekan Ya.<br>
                </li>
              </ol>
			<p>
			<ul>INTERNET BANKING</ul> 
			</p>
              <ol>
                <li> Login ke Internet Banking Mandiri (https://ib.bankmandiri.co.id/).<br>
                </li>
                <li>Pada menu utama, pilih Bayar, lalu pilih Multi Payment.<br>
                </li>
                <li>Pilih akun Anda di Dari Rekening, kemudian di Penyedia Jasa pilih Midtrans.<br>
                </li>
                <li>Masukkan Kode Pembayaran Anda dan klik Lanjutkan.<br>
                </li>
                <li>Konfirmasi pembayaran Anda menggunakan Mandiri Token.<br>
                </li>
              </ol>
			
              <p>&nbsp;</p>
              <p>&nbsp;</p>
          </div>
</div>