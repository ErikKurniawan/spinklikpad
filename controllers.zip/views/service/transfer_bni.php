<div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong>ATM / BANK TRANSFER BNI</strong></p>
              <p><ul>ATM BNI</ul> </p>
              <ol>
                <li>Pada menu utama, pilih Menu Lainnya.<br></li>
                <li>Pilih Transfer.<br>
                </li>
                <li>Pilih Rekening Tabungan.<br>
                </li>
                <li>Pilih Ke Rekening BNI.<br>
                </li>
                <li>Masukkan nomor virtual account dan pilih Tekan Jika Benar.<br>
                </li>
                <li>Masukkan jumlah tagihan yang akan anda bayar secara lengkap. Pembayaran dengan jumlah tidak sesuai akan otomatis ditolak.<br>
                </li>
                <li>Jumlah yang dibayarkan, nomor rekening dan nama Merchant akan ditampilkan. Jika informasi telah sesuai, tekan Ya.</li>
                <li>Transaksi Anda sudah selesai. </li>
              </ol>
			<p><ul>INTERNET BANKING</ul> </p>
              <ol>
                <li>Ketik alamat https://ibank.bni.co.id kemudian klik Masuk.<br>
                </li>
                <li>Silakan masukkan User ID dan Password.<br>
                </li>
                <li>Klik menu Transfer kemudian pilih Tambah Rekening Favorit.<br>
                </li>
                <li>Masukkan nama, nomor rekening, dan email, lalu klik Lanjut.<br>
                </li>
                <li>Masukkan Kode Otentikasi dari token Anda dan klik Lanjut.<br>
                </li>
                <li>Kembali ke menu utama dan pilih Transfer lalu Transfer Antar Rekening BNI.<br>
                </li>
                <li>Pilih rekening yang telah Anda favoritkan sebelumnya di Rekening Tujuan lalu lanjutkan pengisian, dan tekan Lanjut.</li>
                <li>Pastikan detail transaksi Anda benar, lalu masukkan Kode Otentikasi dan tekan Lanjut. </li>
              </ol>
			<p><ul>MOBILE BANKING</ul> </p>
              <ol>
                <li>Buka aplikasi BNI Mobile Banking dan login.<br>
                </li>
                <li>Pilih Transfer.<br>
                </li>
                <li>Pilih Antar Rekening BNI.<br>
                </li>
                <li>Pilih Input Rekening Baru.<br>
                </li>
                <li>Masukkan nomor rekening, lalu tekan Lanjut.<br>
                </li>
                <li>Masukkan Password Transaksi lalu tekan Lanjut.<br>
                </li> 
              </ol>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
          </div>
</div>