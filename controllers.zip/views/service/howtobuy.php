
<div class="row">
<div class="container" style="border:0px solid red;">
          <h4><strong> CARA BELANJA</strong></h4>
              <ol>
                <li>Masuk ke akun Klikpad.com Anda atau daftar akun baru di Klikpad.com<br>
				  <img src="<?php echo URL?>public/images/howtobuy/cara_pembayaran1.png" width="719" height="392" alt=""/>
				  </li><br>
                <li>Cari dan pilih produk yang Anda inginkan <br>
				  <img src="<?php echo URL?>public/images/howtobuy/cara_pembayaran2.png" width="719" height="392" alt=""/>
				  </li><br>
                <li>Klik <strong>“Beli”</strong> untuk melanjutkan ke proses Tambahkan ke Keranjang<br>
				  <img src="<?php echo URL?>public/images/howtobuy/cara_pembayaran3.png" width="719" height="392" alt=""/>
				  </li><br>
                <li>Isi Keterangan, pilih Alamat atau buat Alamat baru, pilih Kurir Pengiriman dan jenis Paket Pengirimannya, lalu klik <strong>“Tambahkan ke Keranjang”</strong><br>
				  <img src="<?php echo URL?>public/images/howtobuy/cara_pembayaran4.png" width="719" height="392" alt=""/>
				  </li><br>
                <li>Klik <strong>“Lanjutkan Belanja”</strong> jika masih ingin menambah produk lain nya, klik <strong>“Lihat Keranjang”</strong> untuk melanjutkan ke proses Checkout <br>
				  <img src="<?php echo URL?>public/images/howtobuy/cara_pembayaran5.png" width="719" height="392" alt=""/>
				  </li><br>
                <li>Periksa lagi produk yang Anda beli dalam Keranjang Anda, kemudian klik <strong>“Pilih Metode Pembayaran”</strong><br>
				  <img src="<?php echo URL?>public/images/howtobuy/cara_pembayaran6.png" width="719" height="392" alt=""/>
				  </li>
              </ol>
</div>
</div>
