
<style>
    .panel-filter
    {
        border:1px solid #f1f1f1;
        padding:10px;
    }


    .panel-filter ul li
    {
        padding:5px 0px;


    }

    .panel-filter ul li,.panel-filter ul li a
    {
        text-decoration: none;
        font-size: 12px;
        padding:0px !important;
        color:#94989b;
    }

    .panel-filter ul li a
    {
        line-height: 20px;
    }

    .panel-filter ul li a:active,.panel-filter ul li a:hover
    {
        color: #6d6e70;
    }

    .panel-container
    {
        border:1px solid #f1f1f1;
    }

    .title-filter
    {
        line-height: 40px;
        font-size: 14px;
        font-weight: bold;
        color:#7f4197;
    }

    .category-title
    {
        font-weight: bold;
        font-size: 20px;
        color: #fff;
        padding: 0 10px;
        background: #7f4197;
        height: 40px;
        line-height: 40px;
    }

</style>
<style>
    .hoverable:not(:hover) + .show-on-hover {
        display: none;
    }

    .product-hover {
        text-align: center;
        background: #231f20;
        color:#d0d1d3;
        font-size: 13px;
        line-height: 35px;

    }
    .product-card:not(:hover) + .product-hover {
        text-align: center;
        background: transparent;
        color:transparent;
        height: 35px;
    }
    .product-site-map
    {
        font-size:14px;
        color:#94989b;
    }

    .product-site-map a
    {
        font-size:14px;
        color:#94989b;
        text-decoration: none;
        margin-right:5px;
    }

    .product-site-map a:hover
    {
        color:#6d6e70;
    }

    .product-site-map div
    {
        width: 10px;
        height: 10px;

        border-bottom: 5px solid transparent;
        border-left: 5px solid #f7931d;
        border-top: 5px solid transparent;
        border-right: 5px solid transparent;
        clear: both;
        display: inline-block;
        margin: 0px 5px;
    }

    .product-site-map a:last-child
    {
        color:#7e3f98;
    }

    .row-product .col
    {

        padding: 0px 15px !important;
    }










    .col-xs-5ths,
    .col-sm-5ths,
    .col-md-5ths,
    .col-lg-5ths {
        position: relative;
        min-height: 1px;
        padding-right: 15px;
        padding-left: 15px;
    }

    .col-xs-5ths {
        width: 20%;
        float: left;
    }

    @media (min-width: 768px) {
        .col-sm-5ths {
            width: 20%;
            float: left;
        }
    }

    @media (min-width: 992px) {
        .col-md-5ths {
            width: 20%;
            float: left;
        }
    }

    @media (min-width: 1200px) {
        .col-lg-5ths {
            width: 20%;
            float: left;
        }
    }


    .sps {
        padding: 1em .5em;
        position: fixed;
        top: 0;
        left: 0;
        transition: all 0.25s ease;
        width: 100%;
    }

    .sps--abv {
        background-color: transparent;
        color: #000;
    }

    .sps--blw {
        
        color: #fff;
    }


    #wrapper{
        border:1px solid black;
        overflow:hidden;
        display: table;
    }






</style>




<div class="container-fluid section content" style="margin-top: -25px;">
    <div style="background:red;width: 100%;height: 200px;">

    </div>
    <div class="row">
        <div class="col-2" >
            <div style=" border: 1px solid black;margin-top: -25px;background: yellow;height: 200px">
                23
            </div>
        </div>

        <div class="col-8">

        </div>
    </div>
</div>















<hr/>
<hr/>
<hr/><hr/>
<hr/>

<h1>REVIEW</h1>



<style>

    .review-container{

    }
    .review-content
    {
        padding:15px 10px;
        border-bottom: 1px solid #e2e7e9;
    }

    .review-content:last-child
    {

        border-bottom: 0px;
    }


    .review-icon-container
    {
        width: 55px;
    }

    .review-content img
    {

        border:5px #e2e7e9 solid;
        width: 50px;
        height: 50px;
    }

    .review-name
    {
        padding:0px 5px;
        color: #733f98;
        font-size: 12px;
        font-weight: bold;
    }

    .review-time
    {
        padding: 5px;
        color: #95999A;
        font-size: 12px;
        font-weight: bold;
        font-style: oblique;
    }


    .review-desc
    {
        padding: 5px;
        color: #6a6c6c;
        font-size: 13px;
        font-weight: bold;
    }

    .img-review-container
    {
        padding: 10px;
        border:1px solid black;
        height: 100%;
        width: 150px;
    }


    .img-review{
        padding: 10px;
        height: 100%;
        width: 150px;


    }
    .img-review img{
        border:1px solid #e2e7e9;

    }

    .img-review a
    {
        color: #95999A;
        text-decoration: none;
        font-weight: bold;
        font-size: 14px;
    }

    .img-review a :hover
    {
        color: #733f98;
        text-decoration: none;
    }



    .parent { display: table;width: 100%; }
    .parent > div {display: table-cell; 
                   border:1px solid #e2e7e9;
                   vertical-align:top; 
    }


    .parent2 { display: table;width: 100%; }
    .parent2 > div {display: table-cell; 

                    vertical-align:top; 
    }
</style>



<div class="container-fluid section content">
    <div class="parent ">
        <div class="img-review-container">
            <div class="img-review">
                <a href="#">

                    <div>
                        <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                        asdas 
                        a 
                        a 
                        a 
                        a 
                        a
                        ash ad asd
                        asd a
                        <br/>jsdh akhdg hasld<br/>
                        asdas 
                        a 
                        a 
                        a 
                        <br/>
                        a 
                        a
                        <br/>
                        ash ad asd
                        asd ajsdh akhdg hasld<br/>
                    </div>
                </a>
            </div>
        </div>
        <div class="review-container">
            <div class="review-content">
                <div class="parent2">
                    <div class="review-icon-container">
                        <img  class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                    </div>
                    <div>

                        <div class="review-name">Erik Kurniawan <span style="background: red;font-weight: normal;padding:5px 15px;color:#fff;border-radius: 2px;">pengguna</span></div>
                        <div class="review-time "> 20/02/2018 19:20:29</div>
                        <div class="review-desc">asd</div>
                    </div>
                </div>
            </div>
            <div class="review-content">
                <form id="frmcomment">
                    <input type="text" class="comment" name="comment" id="comment" >
                </form>
            </div>
        </div>

    </div>
</div>
<hr/><hr/><hr/><hr/><hr/><hr/><hr/><hr/><hr/><hr/><hr/><hr/><hr/><hr/><hr/>





<div class="container-fluid section content">




    <ul class="nav nav-pills mb-3 i-tab" id="pills-tab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Produk</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Ulasan</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Diskusi Produk</a>
        </li>
    </ul>


    <div class="row">
        <div class="col">
            <div id="wrapper">
                <div class="img-review">
                    <a href="#">
                        <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                        <div>asdas 
                            a 
                            a 
                            a 
                            a 
                            a
                            ash ad asd
                            asd ajsdh akhdg hasld
                        </div>
                    </a>
                </div>
                <div class="review-container">
                    <div class="review-content">

                        <div class="review-content">asd</div>
                        <div class="review-content">asd</div>
                    </div>

                </div>
            </div>
            <div>
                asd
            </div>
        </div>
    </div>



    <div class="row">
        <div class="col-2" >
            <div>Search</div>
        </div>
        <div class="col-10" >
            <div class="float-right">orderby</div>
        </div>
    </div>








    <div class="row">
        <div class="col">
            <hr/>
        </div>
    </div>

    <div class="row">
        <div class="col-2" >
            <div style=" border: 1px solid black;background: green;height: 200px">
                Catatan
            </div>

            <div class="sps sps--abv position-sticky" style=" border: 0px solid black;padding: 5px 0px;">
                <div style="background: red;height: 400px;">etalase</div>
            </div>
        </div>

        <div class="col-10">


            <div class="row row-product">
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
            </div>


            <div class="row row-product">
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
            </div>


            <div class="row row-product">
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
            </div>


            <div class="row row-product">
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
                <div class="col">
                    <div class="product-card">
                        <a href="<?= URL ?>/product/detail/haha">
                            <div class="product-image">
                                <img class="img-fluid" src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-04.png" title="kategory 1"/>
                            </div>
                            <div class="product-title">alsdkalsdka dasdlaksd alskd asdasdasdas d asdas</div>
                            <div class="product-sale-price">Rp 2,222,333</div>
                            <div class="product-price">Rp 1,566,371</div>
                            <div class="product-icon">
                                <img class="img-fluid " src="<?= PATH_IMAGE ?>/asset/icon_categories_32px-12.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_cart_32.png" title="kategory 1"/>
                                <img class="img-fluid float-right" src="<?= PATH_IMAGE ?>/asset/icon_wishlist_32.png" title="kategory 1"/>
                            </div>
                        </a>

                    </div>
                    <div class="product-hover">
                        PESAN PRODUK
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>
