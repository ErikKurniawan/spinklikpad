<div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong>GO-PAY</strong></p>
              <ol>
                <li>Mohon selesaikan pembayaran GO-PAY via aplikasi.<br>
                </li>
                <li>Klik Bayar dengan GO-PAY.<br>
                </li>
                <li>Buka aplikasi GO-JEK di HP Anda.<br>
                </li>
                <li>Klik Scan QR.<br>
                </li>
                <li>Arahkan kamera Anda ke Kode QR.<br>
                </li>
                <li>Periksa kembali detail pembayaran Anda di aplikasi GO-JEK dan tekan Pay.<br>
                </li>
                <li>Transaksi Anda selesai. </li>
              </ol>
			  <p>&nbsp;</p>
              <p>&nbsp;</p>
          </div>
</div>