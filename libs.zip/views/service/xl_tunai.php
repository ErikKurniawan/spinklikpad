<div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong>XL TUNAI</strong></p>
              <ol>
                <li>Pembayaran melalui XL-Tunai harus diselesaikan menggunakan nomor ponsel XL terdaftar. Tekan *123*120# untuk informasi lebih lanjut.<br>
                </li>
                <li>Tekan *123*120# pada ponsel Anda.<br>
                </li>
                <li>Pilih menu '4', yaitu 'Belanja Online'.<br>
                </li>
                <li>Masukkan Kode Merchant XL Tunai.<br>
                </li>
                <li>Masukkan Order ID XL Tunai.<br>
                </li>
                <li>Masukkan PIN XL Tunai Anda.<br>
                </li>
                <li>Anda akan menerima SMS Konfirmasi dari XL. </li>
              </ol>
			  <p>&nbsp;</p>
              <p>&nbsp;</p>
          </div>
</div>