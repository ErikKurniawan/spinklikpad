<div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong>INDOSAT DOMPETKU</strong></p>
              <ol>
                <li>Pembayaran ini harus menggunakan nomor telepon yang terdaftar dengan Indosat Dompetku.<br>
                </li>
                <li>Masukkan nomor Indosat Anda yang sudah terdaftar Indosat Dompetku.<br>
                </li>
                <li>Pastikan saldo Anda cukup untuk melakukan transaksi.<br>
                </li>
                <li>Tekan 'Konfirmasi Pembayaran'.<br>
                </li>
                <li>Anda akan mendapatkan pesan USSD dari Indosat untuk melakukan transaksi di app Dompetku.<br>
                </li>
                <li>Masukkan PIN.<br>
                </li>
                <li>Pembayaran selesai. </li>
              </ol>
			  <p>&nbsp;</p>
              <p>&nbsp;</p>
          </div>
</div>