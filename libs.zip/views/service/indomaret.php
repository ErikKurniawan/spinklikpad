<div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong>INDOMARET</strong></p>
              <ol>
                <li>Pembayaran harus diselesaikan di toko Indomaret. </li>
                <li>Setelah melakukan konfirmasi pembayaran, Anda akan diberikan Kode Pembayaran yang unik.<br>
                </li>
                <li>Salinlah Kode Pembayaran Anda dan jumlah pembayaran yang akan dibayarkan. Jangan Khawatir, Kami juga akan mengirimkan salinan Kode Pembayaran dan Instruksi Pembayaran melalui email kepada Anda.<br>
                </li>
                <li>Pergi ke toko Indomaret terdekat dan berikanlah nomor Kode Pembayaran Anda ke kasir.<br>
                </li>
                <li>Kasir Indomaret akan mengkonfirmasi transaksi dengan menanyakan jumlah pembayaran dan nama merchant.<br>
                </li>
                <li>Konfirmasikan pembayaran Anda ke kasir.<br>
                </li>
                <li>Transaksi Anda berhasil! Anda akan mendapatkan email konfirmasi pembayaran dan Simpanlah struk transaksi Indomaret Anda.<br>
                </li>
                
              </ol>
			  <p>&nbsp;</p>
              <p>&nbsp;</p>
          </div>
</div>