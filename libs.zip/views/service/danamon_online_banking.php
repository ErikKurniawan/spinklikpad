        <div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong> DANAMON ONLINE BANKING</strong></p>
              <ol>
                <li>Pembayaran melalui Danamon Online Banking harus diselesaikan di website Danamon. Pastikan Anda telah memiliki User ID Danamon Online Banking sebelum melakukan pembayaran.</li>
                <li> Masukkan User ID dan Password Danamon Online Banking Anda dan pilih sumber rekening untuk pembayaran Anda.</li>
                <li> Cek rincian informasi transaksi Anda, masukkan Kode Token, lalu tekan lanjut.</li>
                <li>Konfirmasi transaksi pembayaran akan muncul, pembayaran selesai. Simpan informasi referensi merchant dan referensi pembayaran, tekan Lanjut untuk kembali ke situs merchant. </li>
              </ol>
            </div>
</div>