        <div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong> KLIK BCA</strong></p>
              <ol>
                <li>Silakan selesaikan pembayaran Anda di KlikBCA dengan membuka www.klikbca.com pada jendela atau tab baru.</li>
                <li> User ID KlikBCA yang Anda masukkan adalah User ID yang masih aktif dan terdaftar di BCA.</li>
                <li> Setelah Anda menyelesaikan transaksi ini, Anda harap melakukan pembayaran melalui halaman KlikBCA dengan membuka www.klikbca.com dari tab terpisah dengan menggunakan User ID yang Anda masukkan di bawah.</li>
                <li>Transaksi Anda akan dibatalkan atau kadaluarsa jika Anda tidak melakukan pembayaran dalam batas waktu 2 jam. </li>
              </ol>
            </div>
</div>