<div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong>ATM / BANK TRANSFER PERMATA</strong></p>
              <ol>
                <li>Pada menu utama, pilih Transaksi Lainnya.<br></li>
                <li>Pilih Pembayaran.<br>
                </li>
                <li>Pilih Pembayaran Lainnya.<br>
                </li>
                <li>Pilih Virtual Account.<br>
                </li>
                <li>Masukkan 16 digit No. Virtual Account yang dituju, lalu tekan Benar.<br>
                </li>
                <li>Pada halaman konfirmasi transfer akan muncul jumlah yang dibayarkan, nomor rekening, &amp; nama Merchant. Jika informasi telah sesuai tekan Benar.<br>
                </li>
                <li>Pilih rekening pembayaran Anda dan tekan Benar. </li>
              </ol>
			  <p>&nbsp;</p>
              <p>&nbsp;</p>
          </div>
</div>