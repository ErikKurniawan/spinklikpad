        <div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong> MANDIRI CLICKPAY</strong></p>
              <ol>
                <li>Ikuti langkah-langkah berikut untuk mengetahui cara membayar dengan kartu kredit: Klik <strong>“Mandiri Clickpay ”</strong> pada kolom Pilih Metode Pembayaran <br>
				<img src="<?php echo  URL?>public/images/howtobuy/mandiri_clickpay1.png" width="719" height="392">
		
				
				  </li>
                <li> Aktifkan Mandiri token Anda dengan menekan ◄.<br></li>
                <li> Masukkan password Mandiri token Anda.<br>
                </li>
                <li>Tekan <strong>3</strong> ketika Mandiri token menampilkan <strong>APPLI</strong>.<br>
                </li>
                <li>Masukkan <strong>Input 1</strong> dan tekan ◄ selama 3 detik.<br>
                </li>
                <li>Masukkan <strong>Input 2</strong> dan tekan ◄ selama 3 detik.</li>
                <li> Masukkan <strong>Input 3</strong> dan tekan ◄ selama 3 detik.</li>
                <li>Masukkan kode yang dihasilkan Mandiri token ke kolom <strong>Masukkan challenge token</strong>. </li>
              </ol>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
          </div>
</div>