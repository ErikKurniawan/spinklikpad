<div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong>ATM / BANK TRANSFER BCA</strong></p>
              <p><ul>ATM BCA</ul> </p>
              <ol>
                <li>Pada menu utama, pilih Transaksi Lainnya.<br></li>
                <li>Pilih Transfer.<br>
                </li>
                <li>Pilih Ke Rek BCA Virtual Account.<br>
                </li>
                <li>Masukkan Nomor Rekening pembayaran Anda lalu tekan Benar.<br>
                </li>
                <li>Masukkan jumlah tagihan yang akan anda bayar.<br>
                </li>
                <li>Pada halaman konfirmasi transfer akan muncul detail pembayaran Anda. Jika informasi telah sesuai tekan Ya.<br>
                </li>
              </ol>
			<p><ul>KLIK BCA</ul> </p>
              <ol>
                <li>Pilih menu Transfer Dana.<br>
                </li>
                <li>Pilih Transfer ke BCA Virtual Account.<br>
                </li>
                <li>Masukkan nomor BCA Virtual Account, atau pilih Dari Daftar Transfer.<br>
                </li>
                <li>Jumlah yang akan ditransfer, nomor rekening dan nama merchant akan muncul di halaman konfirmasi pembayaran, jika informasi benar klik Lanjutkan.<br>
                </li>
                <li>Ambil BCA Token Anda dan masukkan KEYBCA Response APPLI 1 dan Klik Submit.<br>
                </li>
                <li>Transaksi Anda selesai.<br>
                </li>
              </ol>
			<p><ul>m-BCA</ul> </p>
              <ol>
                <li>Lakukan log in pada aplikasi BCA Mobile.<br>
                </li>
                <li>Pilih menu m-BCA, kemudian masukkan kode akses m-BCA.<br>
                </li>
                <li>Pilih m-Transfer > BCA Virtual Account.<br>
                </li>
                <li>Pilih dari Daftar Transfer, atau masukkan Nomor Virtual Account tujuan.<br>
                </li>
                <li>Masukkan jumlah yang ingin dibayarkan.<br>
                </li>
                <li>Masukkan pin m-BCA.<br>
                </li>
				<li>Pembayaran selesai. Simpan notifikasi yang muncul sebagai bukti pembayaran.<br>
                </li>  
              </ol>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
          </div>
</div>