 <div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong>ATM / BANK TRANSFER BANK LAINNYA</strong></p>
              <ol>
                <li>Pada menu utama, pilih Transaksi Lainnya.<br></li>
                <li>Pilih Transfer.<br>
                </li>
                <li>Pilih Rek Bank Lain.<br>
                </li>
                <li>Masukkan nomor 009 (kode Bank BNI) lalu tekan Benar.<br>
                </li>
                <li>Masukkan jumlah tagihan yang akan Anda bayar secara lengkap, pembayaran dengan jumlah tidak sesuai akan otomatis ditolak.<br>
                </li>
                <li>Masukkan 16 digit No. Rekening pembayaran lalu tekan Benar.<br>
                </li>
                <li>Pada halaman konfirmasi transfer akan muncul jumlah yang dibayarkan, nomor rekening &amp; nama Merchant. Jika informasi telah sesuai tekan Benar. </li>
              </ol>
			  <p>&nbsp;</p>
              <p>&nbsp;</p>
          </div>
</div>