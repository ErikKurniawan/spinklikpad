
        <div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong>LINE PAY e-CASH / MANDIRI e-CASH</strong></p>
              <ol>
                <li>Pembayaran melalui LINE Pay e-cash | mandiri e-cash harus diselesaikan di website Mandiri. Pastikan Anda telah mendaftarkan nomor ponsel untuk LINE Pay e-cash | mandiri e-cash.<br>
                </li>
                <li>Klik Konfirmasi Pembayaran.<br>
                </li>
                <li>Masukkan nomor ponsel yang sudah terdaftar dan PIN Anda.<br>
                </li>
                <li>Tunggu kiriman SMS e-cash yang berisi One Time Password (OTP).<br>
                </li>
                <li>Masukkan kode 6 angka OTP yang diterima, kemudian tekan tombol bayar untuk melakukan pembayaran.<br>
                </li>
                <li>Jika SMS OTP belum diterima / OTP Anda kadaluarsa dalam 5 menit. Klik tombol batal untuk mengulang transaksi dan Anda belum di debet.<br>
                </li>
                
              </ol>
			  <p>&nbsp;</p>
              <p>&nbsp;</p>
          </div>
</div>