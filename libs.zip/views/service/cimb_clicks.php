 <div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong> CIMB CLICKS</strong></p>
              <ol>
                <li>Pembayaran melalui CIMB Clicks harus diselesaikan di website CIMB Clicks. Pastikan Anda telah memiliki User ID CIMB Clicks dan sudah mendaftarkan mPIN sebelum melakukan pembayaran.</li>
                <li> Pastikan Anda telah memiiki User ID CIMB Clicks dan sudah mendaftarkan mPIN sebelum melakukan pembayaran melalui CIMB Clicks ini.</li>
                <li> Pembayaran melalui CIMB Clicks akan diproses secara online, saldo rekening CIMB Anda akan didebet secara otomatis sesuai jumlah pembelanjaan Anda.</li>
                <li>Transaksi Anda akan dibatalkan jika pembayaran tidak diselesaikan dalam 2 jam. </li>
                <li> Pastikan tidak ada pop up blocker yang aktif pada browser Anda.</li>
              </ol>
            </div>
</div>