        <div id="maincontainer">
            <div class="container" style="border:0px solid red;">
              <p><strong>TELKOMSEL CASH</strong></p>
              <ol>
                <li>Pembayaran melalui T-Cash harus diselesaikan menggunakan nomor ponsel telkomsel yang telah terdaftar.<br>
                </li>
                <li>Kirim SMS ke Telkomsel, ketik TOKEN &lt;PIN&gt;, kirim ke 2828.<br>
                </li>
                <li>Masukkan token yang didapatkan dari SMS balasan Telkomsel ke kolom TOKEN T-CASH.<br>
                </li>
                <li>Transaksi Anda akan dibatalkan jika Anda tidak melakukan pembayaran dalam waktu 30 menit.<br>
                </li>
              </ol>
			  <p>&nbsp;</p>
              <p>&nbsp;</p>
          </div>
</div>