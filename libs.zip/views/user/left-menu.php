<style>

    .sps {
        padding: 1em .5em;
        position: fixed;
        top: 0;
        left: 0;
        transition: all 0.25s ease;
        width: 100%;
    }

    .sps--abv {
        background-color: transparent;
        color: #000;
    }

    .sps--blw {

        color: #fff;
    }



    .left-menu ul li
    {
        padding:5px 0px;


    }

    .left-menu ul li,.left-menu ul li a
    {
        text-decoration: none;
        font-size: 12px;
        padding:0px !important;
        color:#94989b;
    }
    .left-menu .title-accordion
    {
        font-size: 14px;
        font-weight: bold;
        color:#733f98;
    }
    .left-menu .title-accordion:after
    {
        font-family: "Font Awesome 5 Free";
        font-weight: 900; 
        content: "\f0d8";
        float: right;
        transition: all 0.5s;
    }

    .left-menu .title-accordion.active:after
    {
        -webkit-transform: rotate(180deg);
        -moz-transform: rotate(180deg);
        transform: rotate(180deg);
    }



    .left-menu ul li a
    {
        line-height: 30px;
    }

    .left-menu ul li a:active,.left-menu ul li a:hover
    {
        color: #733f98;
    }

</style>


<script>
  
    $(function () {
    
        $('.title-accordion').on('show.bs.collapse', function () {
            $(this).siblings('.panel-heading').addClass('active');
        });

        $('.panel-collapse').on('hide.bs.collapse', function () {
            $(this).siblings('.panel-heading').removeClass('active');
        });
    });

</script>
<div class="sps sps--abv position-sticky" style=" border: 0px solid black;padding: 0px 0px;">
    <div class="left-menu" style="border:1px solid #d2d2d2;padding:10px;">
        <div style="padding-bottom: 15px;margin-bottom: 10px; border-bottom:1px solid #d2d2d2;">
            <img style="border:2px solid #d2d2d2;width: 48px; height: 48px;" class="center" src="http://localhost/klikpad/public/image/asset/icon_categories_32px-05.png" title="kategory 1">
            <span style="font-size:12px; color:#733f98;font-weight: bold;">Erik Kurniawan</span>

        </div>


        <ul id="accordion1" class="nav nav-pills flex-column">
            <li class="nav-item">
                <a class="title-accordion nav-link" data-toggle="collapse" href="#item-1" data-parent="#accordion1">Profile</a>
                <div id="item-1" class="collapse show">
                    <ul class="nav flex-column ml-3">
                        <li class="nav-item">
                            <a class="nav-link" href="<?= URL ?>purchase">Pembelian</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= URL ?>wishlist">Wishlist</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= URL ?>user">Pengaturan</a>
                        </li>
                    </ul>
                </div>
            </li>

        </ul>

        <ul id="accordion2" class="nav nav-pills flex-column">
            <li class="nav-item">
                <a class="title-accordion nav-link" data-toggle="collapse" href="#item-2" data-parent="#accordion2">Kotak Masuk</a>
                <div id="item-2" class="collapse show">
                    <ul class="nav flex-column ml-3">
                        <li class="nav-item">
                            <a class="nav-link" href="<?=URL?>user/review">Ulasan</a>
                        </li>
                        <!--
                        <li class="nav-item">
                            <a class="nav-link" href="#">Chat</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Diskusi Produk</a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link" href="#">Pesan Bantuan</a>
                        </li>
                        -->
                    </ul>
                </div>
            </li>

        </ul>
    </div>
</div>