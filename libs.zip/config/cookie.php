<?php

define('COOKIE_SIGNIN', 'signin');
define('COOKIE_ERROR_SIGNIN', 'errsignin');
define('COOKIE_MSG_INFO', 'msginfo');
define('COOKIE_USER', 'email');
define('COOKIE_PWD', 'pwd');
/* ==================================================================================================== */
